
using UnityEngine;
using UnityEngine.SceneManagement;

public class BtnSpace : MonoBehaviour
{
    private void Update()
    {
        if (Input.GetKeyDown(KeyCode.Space))
        {
            SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
        }
    }

    public void Play()
    {
        SceneManager.LoadScene(1);
    }
}
