
using UnityEngine;
using UnityEngine.UI;

public class ShowRankYout : MonoBehaviour
{
    [SerializeField] private Sprite[] _sprite;
    [SerializeField] private int _needScore;

    private void OnEnable()
    {
        GetComponent<Image>().color = Color.red;
        if (_needScore <= PlayerPrefs.GetInt("Score"))
        {
            GetComponent<Image>().color = Color.green;
        }
    }
}
