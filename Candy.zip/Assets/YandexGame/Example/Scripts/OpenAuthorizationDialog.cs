using UnityEngine;

namespace YG.Example
{
    public class OpenAuthorizationDialog : MonoBehaviour
    {
        public void OpenAuthDialog()
        {
            YandexGame.AuthDialog();
        }
    }
}