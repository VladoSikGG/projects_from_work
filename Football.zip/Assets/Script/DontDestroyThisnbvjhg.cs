using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DontDestroyThisnbvjhg : MonoBehaviour
{
    void Awake()
    {
        GameObject obj = GameObject.FindWithTag("Music");
        if(obj != null) Destroy(gameObject);
        else
        {
            gameObject.tag = "Music";
            DontDestroyOnLoad(gameObject);
        }
        
    }
}
