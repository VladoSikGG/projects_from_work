using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.Serialization;

public class BetManagervbnieu : MonoBehaviour
{
    [SerializeField] private TMP_Text _betTextvuyter;
    [SerializeField] private GameObject _panelDirvbnvbn;
    private int _currentBetefhufh;
    private int _currentBalancevbnfij;

    public int GetBetoisuaa() { return _currentBetefhufh;}

    private void Update()
    {
        Debug.Log($"Balance: {_currentBalancevbnfij} \n" +
                  $" Bet: {_currentBetefhufh} \n" +
                  $" Level: {PlayerPrefs.GetInt("CurrentLevel")}\n" +
                  $"OpenLevel: {PlayerPrefs.GetInt("OpenLevel")}");
    }
    private void OnEnable()
    {
        if (PlayerPrefs.GetInt("Balance") < 100)
        {
            PlayerPrefs.SetInt("Balance", 300);
        }
        _currentBalancevbnfij = PlayerPrefs.GetInt("Balance");
        _currentBetefhufh = ((_currentBalancevbnfij / 4) - (_currentBalancevbnfij / 4 % 10));
        if (_currentBetefhufh < 10) _currentBetefhufh = 10;
        UpdateInfovbnvbn();
    }

    public void IncreaseBetgpoiuy()
    {
        _currentBetefhufh += 10;
        if (_currentBalancevbnfij / 2 < _currentBetefhufh) _currentBetefhufh = (_currentBalancevbnfij / 2) - (_currentBalancevbnfij/2 % 10);
        UpdateInfovbnvbn();
    }
    
    public void DecreaseBetfudiop()
    {
        _currentBetefhufh -= 10;
        if (_currentBetefhufh <= 10) _currentBetefhufh = 10;
        UpdateInfovbnvbn();
    }

    public void ConfirmBetjjjggg()
    {
        _panelDirvbnvbn.SetActive(true);
        gameObject.SetActive(false);
    }

    private void UpdateInfovbnvbn()
    {
        _betTextvuyter.text = _currentBetefhufh.ToString();
    }
}
