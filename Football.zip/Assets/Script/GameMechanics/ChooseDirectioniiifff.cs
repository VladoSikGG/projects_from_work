using System.Collections;
using DG.Tweening;
using UnityEngine;
using UnityEngine.UI;
using Random = UnityEngine.Random;

public class ChooseDirectioniiifff : MonoBehaviour
{
    [Header("For Shoot")]
    [SerializeField] private Transform[] _endPointsioeufy;
    [SerializeField] private Transform _ballibceuh;
    [SerializeField] private Transform _goalKeeperienbus;
    [SerializeField] private Sprite _keeperJumpioduyw;
    [SerializeField] private float _speedAnimationcnspkj = 1;
    [SerializeField] private GameObject _panelDirectioncmslzu;
    
    [Header("For Result")] 
    [SerializeField] private GameObject _correctPanelcoqwnh;
    [SerializeField] private GameObject _missPaneldushxb;
    [SerializeField] private GameObject _betPanelsyquak;
    [SerializeField] private Transform _startPosKeeperdhcbnf;
    [SerializeField] private Transform _startPosBallsbcnfj;
    [SerializeField] private StatManagervjiruy _statManageraysudi;
    [SerializeField] private BetManagervbnieu _betManagervbnieu;
    [SerializeField] private AudioSource _sndWinoiuoiu, _sndLosejhgghj, _udarnjiuhb;
    

    private bool _playerIsKeeperfiruth = false;
    private Transform _playerfieort, _botcbnfio;
    private int _botValuevcipeo, _playerValuevnfoei;
    private Sprite _startSpriteKeepercsifeh;

    private void Start()
    {
        
        if (PlayerPrefs.GetString("Mode") == "Ball")
        {
            _playerfieort = _ballibceuh;
            _botcbnfio = _goalKeeperienbus;
        }
        else
        {
            _playerfieort = _goalKeeperienbus;
            _botcbnfio = _ballibceuh;
        }
        _startSpriteKeepercsifeh = _goalKeeperienbus.GetComponent<Image>().sprite;
    }

    public void Chosenfueiso(int value)
    {
        _udarnjiuhb.Play();
        _goalKeeperienbus.GetComponent<Image>().sprite = _keeperJumpioduyw;
        _ballibceuh.DOScale(Vector3.one * 0.4f, _speedAnimationcnspkj);
        PlayerChoosevifuzo(value);
        BotChooseqweppb();
        _panelDirectioncmslzu.SetActive(false);
        StartCoroutine(CheckShootgotiru());

    }

    private void PlayerChoosevifuzo(int point)
    {
        _playerfieort.DOMove(_endPointsioeufy[point].position, _speedAnimationcnspkj);
        RotateObjectvndasw(point, _playerfieort.gameObject);
        _playerValuevnfoei = point;
    }
    private void BotChooseqweppb()
    {
        int botChance = Random.Range(0, 6);
        int randomPoint = Random.Range(0, _endPointsioeufy.Length);
        if (botChance < 3) randomPoint = _playerValuevnfoei;
        
        _botcbnfio.DOMove(_endPointsioeufy[randomPoint].position, _speedAnimationcnspkj);
        RotateObjectvndasw(randomPoint, _botcbnfio.gameObject);
        _botValuevcipeo = randomPoint;
    }

    private void RotateObjectvndasw(int value, GameObject who)
    {
        if (value == 0 || value == 1) who.transform.DORotate(new Vector3(0, 0, -22.5f), _speedAnimationcnspkj);
        else if (value == 3) who.transform.DORotate(new Vector3(0, 0, -90f), _speedAnimationcnspkj);
        else if (value == 5 || value == 4) who.transform.DORotate(new Vector3(0, 0, 22.5f), _speedAnimationcnspkj);
        else if (value == 2) who.transform.DORotate(new Vector3(0, 0, 90f), _speedAnimationcnspkj);
    }

    private IEnumerator CheckShootgotiru()
    {
        yield return new WaitForSecondsRealtime(_speedAnimationcnspkj / 2);
        if (PlayerPrefs.GetString("Mode") == "Ball")
        {
            if (_botValuevcipeo == _playerValuevnfoei)
            {
                PlayerPrefs.SetInt("Balance", PlayerPrefs.GetInt("Balance") - _betManagervbnieu.GetBetoisuaa());
               _statManageraysudi.AddMissShootnasudy();
                _missPaneldushxb.SetActive(true);
                _sndLosejhgghj.Play();
                Blinkinguuutyf(_missPaneldushxb);
            }
            else
            {
                PlayerPrefs.SetInt("Balance", PlayerPrefs.GetInt("Balance") + _betManagervbnieu.GetBetoisuaa());
                //_statManageraysudi.AddRightShootnasudy();
                _correctPanelcoqwnh.SetActive(true);
                _sndWinoiuoiu.Play();
                Blinkinguuutyf(_correctPanelcoqwnh);
            }
        }
        else
        {
            if (_botValuevcipeo == _playerValuevnfoei)
            {
                PlayerPrefs.SetInt("Balance", PlayerPrefs.GetInt("Balance") + _betManagervbnieu.GetBetoisuaa());
                //_statManageraysudi.AddRightShootnasudy();
                _correctPanelcoqwnh.SetActive(true);
                _sndWinoiuoiu.Play();
                Blinkinguuutyf(_correctPanelcoqwnh);
                
            }
            else
            {
                PlayerPrefs.SetInt("Balance", PlayerPrefs.GetInt("Balance") - _betManagervbnieu.GetBetoisuaa());
                _statManageraysudi.AddMissShootnasudy();
                _missPaneldushxb.SetActive(true);
                _sndLosejhgghj.Play();
                Blinkinguuutyf(_missPaneldushxb);
            }
        }
        

        yield return new WaitForSecondsRealtime(3);
        DOTween.KillAll();
        RestartScenequsyai();
        _statManageraysudi.MadeShootalalal();
    }

    private void Blinkinguuutyf(GameObject blinkObj)
    {
        Sequence blinking = DOTween.Sequence();
        blinking.Append(blinkObj.GetComponent<Image>().DOColor(Color.white, _speedAnimationcnspkj/2));
        blinking.Append(blinkObj.GetComponent<Image>().DOColor(new Color(1,1,1,0.5f), _speedAnimationcnspkj/2));
        blinking.SetLoops(-1);
        
    }

    private void RestartScenequsyai()
    {
        _missPaneldushxb.SetActive(false);
        _correctPanelcoqwnh.SetActive(false);

        _ballibceuh.DOMove(_startPosBallsbcnfj.position, _speedAnimationcnspkj);
        _ballibceuh.DORotate(Vector3.zero, _speedAnimationcnspkj/2);
        _ballibceuh.localScale = Vector3.one;
        _goalKeeperienbus.DOMove(_startPosKeeperdhcbnf.position, _speedAnimationcnspkj);
        _goalKeeperienbus.DORotate(Vector3.zero, _speedAnimationcnspkj/2);
        _goalKeeperienbus.GetComponent<Image>().sprite = _startSpriteKeepercsifeh;
        
        _betPanelsyquak.SetActive(true);
        _playerValuevnfoei = 0;
        _botValuevcipeo = 0;
    }
}
