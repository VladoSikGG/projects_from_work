using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.Serialization;

public class StatManagervjiruy : MonoBehaviour
{
    [SerializeField] private GameObject _panelWinvnvnvn;
    [SerializeField] private GameObject _panelLoselpodif;

    [SerializeField] private int _attemptsiuytry = 6;
    private int _numLeveloidddy;
    private int _rightShootbvsnh = 0,_missedBalls = 0, _currentAttemptevbukg;

    private void Start()
    {
        _attemptsiuytry += 2 * (PlayerPrefs.GetInt("CurrentLevel") - 1);
        _numLeveloidddy = PlayerPrefs.GetInt("CurrentLevel");
    }

    public void GoToMainertyui()
    {
        SceneManager.LoadScene(0);
    }

    public void NextScenepolihg()
    {
        if (PlayerPrefs.GetInt("CurrentLevel") + 1 < 21)
        {
            PlayerPrefs.SetInt("CurrentLevel", PlayerPrefs.GetInt("CurrentLevel") + 1);
            
        }
        
        RestartScenepolihg();
    }
    public void RestartScenepolihg()
    {
        SceneManager.LoadScene(SceneManager.GetActiveScene().buildIndex);
    }
    public void MadeShootalalal()
    {
        Debug.Log($"miss: {_missedBalls}\n" +
                  $"Attempt: {_currentAttemptevbukg}");
        _currentAttemptevbukg++;
        if (_currentAttemptevbukg >= _attemptsiuytry)
        {
            WinLevelvnfieh();
            return;
        }
        if (_missedBalls > _attemptsiuytry/2)
        {
            LoseLeveleiuryf();
        }
    }
    
    // public void AddRightShootnasudy()
    // {
    //     _rightShootbvsnh++;
    // }
    public void AddMissShootnasudy()
    {
        _missedBalls++;
    }

    // public void CheckPanelodfuhf()
    // {
    //     if (_rightShootbvsnh >= _attemptsiuytry/2)
    //     {
    //         WinLevelvnfieh();
    //     }
    //     else
    //     {
    //         LoseLeveleiuryf();
    //     }
    // }

    private void WinLevelvnfieh()
    {
        if (PlayerPrefs.GetInt($"Lvl{_numLeveloidddy}") != 2)
        {
            PlayerPrefs.SetInt($"Lvl{_numLeveloidddy}", 2);
            PlayerPrefs.SetInt("OpenLevel", PlayerPrefs.GetInt("OpenLevel") + 1);
            PlayerPrefs.SetInt($"Lvl{PlayerPrefs.GetInt("OpenLevel")}", 1);
        }
        
        
        _panelWinvnvnvn.SetActive(true);
        _panelWinvnvnvn.transform.localScale = Vector3.zero;
        _panelWinvnvnvn.transform.DOScale(Vector3.one, 1);
    }
    private void LoseLeveleiuryf()
    {
        _panelLoselpodif.SetActive(true);
        _panelLoselpodif.transform.localScale = Vector3.zero;
        _panelLoselpodif.transform.DOScale(Vector3.one, 1);
    }
}
