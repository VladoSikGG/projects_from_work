using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class SetModeuhreyt : MonoBehaviour
{
    public void Actionweryui(string nameoklokl)
    {
        PlayerPrefs.SetString("Mode", nameoklokl);
        SceneManager.LoadScene(1);
    }
}
