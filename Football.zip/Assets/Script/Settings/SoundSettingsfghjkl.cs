using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SoundSettingsfghjkl : MonoBehaviour
{
    public void ChangeSettingsjghfd(string namebnhgvc)
    {
        if(PlayerPrefs.GetInt(namebnhgvc) == 0) PlayerPrefs.SetInt(namebnhgvc, 1);
        else PlayerPrefs.SetInt(namebnhgvc, 0);
    }
}
