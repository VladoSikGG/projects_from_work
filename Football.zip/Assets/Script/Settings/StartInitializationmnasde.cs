using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class StartInitializationmnasde : MonoBehaviour
{
    [SerializeField] private int _startBalancejifrji = 100, _startOpenLevelytruty = 11;
    private void Start()
    {
        if (!PlayerPrefs.HasKey("Balance"))
        {
            PlayerPrefs.SetInt("Balance", _startBalancejifrji);
            for (int i = 0; i < _startOpenLevelytruty; i++)
            {
                PlayerPrefs.SetInt($"Lvl{i+1}", 1);
            }
            PlayerPrefs.SetInt("OpenLevel", _startOpenLevelytruty);
            PlayerPrefs.SetInt("Sound", 1);
            PlayerPrefs.SetInt("Music", 1);
        }
    }
}
