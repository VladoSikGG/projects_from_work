using System;
using UnityEngine;

public class VolumeSettingscndjei : MonoBehaviour
{
    [SerializeField] private string _nameSoundmnbvcc;

    private void Update()
    {
        GetComponent<AudioSource>().volume = PlayerPrefs.GetInt(_nameSoundmnbvcc);
    }
}
