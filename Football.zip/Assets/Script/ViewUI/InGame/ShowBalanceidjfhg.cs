using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ShowBalanceidjfhg : MonoBehaviour
{
    void Update()
    {
        GetComponent<TMP_Text>().text = PlayerPrefs.GetInt("Balance").ToString();
    }
}
