using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LeaderbordManageriuytre : MonoBehaviour
{
    [SerializeField] private Transform _strokesParentuhbygv;
    //[SerializeField] private ScoreFieldygthgh _fieldPlayerokmlll;

    private void OnEnable()
    {
        for (int i = 0; i < 9; i++)
        {
            _strokesParentuhbygv.GetChild(i).gameObject.SetActive(true);
        }
        SortLeaderskmjnhb();
        _strokesParentuhbygv.GetChild(8).gameObject.SetActive(false);
    }
    private void OnDisable()
    {
        for (int i = 0; i < 9; i++)
        {
            _strokesParentuhbygv.GetChild(i).gameObject.SetActive(false);
        }
    }

    private void SortLeaderskmjnhb()
    {
        int lengthuytjhg = _strokesParentuhbygv.childCount;
        for (var i = 1; i < lengthuytjhg; i++)
        {
            for (var j = 0; j < lengthuytjhg - i; j++)
            {
                if (_strokesParentuhbygv.GetChild(j).GetComponent<ScoreFieldygthgh>().GetScorewertyu() < 
                    _strokesParentuhbygv.GetChild(j+1).GetComponent<ScoreFieldygthgh>().GetScorewertyu())
                {
                    _strokesParentuhbygv.GetChild(j).SetSiblingIndex(_strokesParentuhbygv.GetChild(j).GetSiblingIndex() + 1);
                }
            }
        }
    }


}
