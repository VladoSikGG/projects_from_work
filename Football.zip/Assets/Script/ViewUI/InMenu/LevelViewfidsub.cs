using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class LevelViewfidsub : MonoBehaviour
{
    [SerializeField] private int _numLeveliuytre;
    [SerializeField] private Sprite[] _spritesuhfuhf;

    private void OnEnable()
    {
        GetComponent<Button>().onClick.AddListener( () => PlayerPrefs.SetInt("CurrentLevel", _numLeveliuytre));
        _numLeveliuytre = transform.GetSiblingIndex() + 1;
        transform.GetChild(0).GetComponent<TMP_Text>().text = _numLeveliuytre.ToString();
        GetComponent<Image>().sprite = _spritesuhfuhf[PlayerPrefs.GetInt($"Lvl{_numLeveliuytre}")];
        if (PlayerPrefs.GetInt($"Lvl{_numLeveliuytre}") == 0) GetComponent<Button>().interactable = false;
    }
}
