using System;
using System.Collections;
using System.Collections.Generic;
using DG.Tweening;
using UnityEngine;

public class LoadingImageivhfgd : MonoBehaviour
{
    [SerializeField] private GameObject _mainMenuafdsds, _btnSettingspoiuyt, _panelCountrybhuvgy;
    private void Start()
    {
        StartCoroutine(Loadingvubrhg());
    }

    private IEnumerator Loadingvubrhg()
    {
        transform.GetChild(0).DORotate(new Vector3(0, 0, -360), 1, RotateMode.LocalAxisAdd).SetLoops(-1).SetEase(Ease.Linear);
        yield return new WaitForSecondsRealtime(6);
        DOTween.KillAll();
        _btnSettingspoiuyt.SetActive(true);
        _mainMenuafdsds.SetActive(true);
        if (!PlayerPrefs.HasKey("Country"))
        {
           _panelCountrybhuvgy.SetActive(true); 
        }
        gameObject.SetActive(false);
    }
}
