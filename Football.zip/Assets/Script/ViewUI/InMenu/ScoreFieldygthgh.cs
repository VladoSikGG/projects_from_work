using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

public class ScoreFieldygthgh : MonoBehaviour
{
    [SerializeField] private int _scoreijnijn;
    [SerializeField] private string _namewesdxc, _countrylkmbnv;
    [SerializeField] private bool _isPlayeruytrew;
    [SerializeField] private TMP_Text _textNameuhfjrk, _textCountryoiutnb, _textScoreysgafd;

    private void OnEnable()
    {
        if (_isPlayeruytrew)
        {
            _namewesdxc = "YOU";
            _countrylkmbnv = PlayerPrefs.GetString("Country");
            _scoreijnijn = PlayerPrefs.GetInt("Balance");
        }
        _textNameuhfjrk.text = _namewesdxc; 
        _textCountryoiutnb.text = _countrylkmbnv; 
        _textScoreysgafd.text = _scoreijnijn.ToString();
        
    }

    public int GetScorewertyu()
    {
        return _scoreijnijn;
    }

    public bool CheckPlayerygvuhb()
    {
        return _isPlayeruytrew;
    }
}
