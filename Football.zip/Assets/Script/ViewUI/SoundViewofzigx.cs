using System;
using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;
using NotImplementedException = System.NotImplementedException;

public class SoundViewofzigx : MonoBehaviour
{
    [SerializeField] private string _namecccoik;
    [SerializeField] private Sprite _onuytrew, _offqwerty;

    private void Update()
    {
        if (PlayerPrefs.GetInt(_namecccoik) == 0)
        {
            transform.GetChild(0).GetComponent<TMP_Text>().text = "OFF";
            GetComponent<Image>().sprite = _offqwerty;
        }
        else
        {
            transform.GetChild(0).GetComponent<TMP_Text>().text = "ON";
            GetComponent<Image>().sprite = _onuytrew;
        }
    }
}
